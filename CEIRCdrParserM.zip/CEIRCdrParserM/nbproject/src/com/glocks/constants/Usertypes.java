package com.glocks.constants;

public interface Usertypes {

	String CUSTOM = "Custom";
	String RETAIILER = "Retailer";
	String IMPORTER = "Importer";
	String DISTRIBUTOR = "Distributor";
	String CEIR_ADMIN = "CEIRAdmin";
	String OPERATOR = "Operator";
	String TRC = "TRC";     
	String MANUFACTURER= "Manufacturer";
	String SYSTEM_ADMIN = "SystemAdmin";
	String LAWFUL_AGENCY = "Lawful Agency";
	String END_USER = "End User";
	String IMMIGRATION = "Immigration";
	String ANONYMOUS = "Anonymous";
	String CUSTOMER_CARE= "Customer Care";
	String OPERATION = "Operation";
	String DRT= "DRT";

}
