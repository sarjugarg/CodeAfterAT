package com.gl.reader.constants;

public interface Alerts {
	String ALERT_006 = "alert006";

}
